package oop;

//siin klassis määrame parkimise tunni hinna (1.5 eurot tund)
public class ParkimiseSekundiHinnad {
    private static double autoSekundiHind = 0.15;
    private static double bussiSekundiHind = 0.25;


    public static double getAutoTunniHind() {
        return autoSekundiHind;
    }

    public static double getBussiTunniHind() {
        return bussiSekundiHind;
    }
}

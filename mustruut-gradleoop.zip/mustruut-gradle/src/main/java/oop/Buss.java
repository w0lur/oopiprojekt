package oop;

public class Buss extends Auto {
    private String regNr; //auto registreerimisnumber


}

package oop;

public class ParkimiseErind extends RuntimeException{
    public ParkimiseErind(String message) {
        super(message);
    }
}


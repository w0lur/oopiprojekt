package oop;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.time.temporal.ChronoUnit;
import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.concurrent.Flow;


public class MustRuut extends Application {
    private String autoTüüp;
    @Override
    public void start(Stage peaLava) throws Exception {

        FlowPane flow = new FlowPane();
        BorderPane border = new BorderPane();
        border.setMinWidth(250);

        FlowPane flow2 = new FlowPane(); //alusta parkimise flowpane
        BorderPane border2 = new BorderPane();
        border2.setMinWidth(250);

        FlowPane flow3 = new FlowPane(); //lõpeta parkimise flowpane
        BorderPane border3 = new BorderPane();
        border3.setMinWidth(250);

        FlowPane flow4 = new FlowPane(); //lõpeta parkimise flowpane
        BorderPane border4 = new BorderPane();
        border4.setMinWidth(250);

        Button välju = new Button("Välju");
        Button alustaParkimist = new Button("Alustan parkimist");
        Button lõpetaParkimine = new Button("Lõpetan parkimise");
        Button start = new Button("Start");
        Button lõpeta = new Button("Lõpeta");
        Button auto = new Button("Auto");
        Button buss = new Button("Buss");
        Button alusta = new Button("Alusta");

        Label lõppTeave = new Label();
        Label samaAutoNr = new Label();
        Label silt1 = new Label("Tere tulemast kasutama parkimiskella!");

        TextArea hoiatus = new TextArea("");
        TextField tekst2 = new TextField("Sõiduki registrinumber");
        TextField tekst = new TextField("Teie nimi");
        TextField tekst1 = new TextField("Sõiduki registrinumber");

        border2.setLeft(auto);
        border2.setRight(buss);
        flow2.getChildren().addAll(auto, buss, tekst, tekst1, alusta, hoiatus);

        flow3.getChildren().addAll(tekst2, lõpeta, samaAutoNr);

        flow4.getChildren().addAll(lõppTeave, välju);

        VBox teine = new VBox();
        teine.getChildren().addAll(silt1, start);
        teine.setAlignment(Pos.CENTER);
        border.setCenter(teine);
        flow.getChildren().add(border);

        BorderPane border1 = new BorderPane();
        VBox esimene = new VBox();
        esimene.getChildren().addAll(alustaParkimist,lõpetaParkimine);
        esimene.setAlignment(Pos.CENTER);
        border1.setCenter(esimene);

        Scene stseen = new Scene(flow, 350, 150, Color.SNOW);

        Scene stseen2 = new Scene(flow2, 350, 150, Color.SNOW);

        Scene stseen1 = new Scene(border1, 350, 150, Color.SNOW);

        Scene stseen3 = new Scene(flow3, 350, 150, Color.SNOW);

        Scene stseen4 = new Scene(flow4, 350, 150, Color.SNOW);

        start.setOnAction(actionEvent -> {
            peaLava.setScene(stseen1);
        });

        alustaParkimist.setOnAction(actionEvent -> {
            peaLava.setScene(stseen2);
        });

        lõpetaParkimine.setOnAction(actionEvent -> {
            peaLava.setScene(stseen3);

        });
        auto.setOnAction(actionEvent -> { //salvestab aja faili
            autoTüüp = "auto";
        });
        buss.setOnAction(actionEvent -> { //salvestab aja faili
            autoTüüp = "buss";
        });

        alusta.setOnAction(actionEvent -> {
            if(autoTüüp != null && !tekst.getText().isEmpty() && !tekst1.getText().isEmpty() && tekst1.getText().length() <= 7) {
                if (loeFailist(tekst1.getText()) != 0) {
                    samaAutoNr.setText("Sellise numbriga auto on juba pargitud.");
                    throw new ParkimiseErind("See auto on juba pargitud");
                }else {
                    kirjutaFaili(autoTüüp, tekst.getText(), tekst1.getText());
                    peaLava.setScene(stseen1);
                }
            }else{
                throw new ParkimiseErind("Auto reg nr on liiga pikk või te ei valinud sõidukitüüpi!");
            }
        });
        lõpeta.setOnAction(actionEvent -> {

            double tasu = 0;
            peaLava.setScene(stseen4);
            if (tekst2.getText() != null) {
                tasu = loeFailist(tekst2.getText())*0.15;
            }
            tasu = tasu*100;
            tasu = Math.round(tasu);
            tasu = tasu /100;
            lõppTeave.setText("Tänan, et parkisite. Teie parkimisesumma on: " + tasu + " eurot.");

            try {
                System.out.println("Eemaldan");
                eemaldaFailist(tekst2.getText());
            } catch (IOException e) {
                e.printStackTrace();
            }
        });



        välju.setOnAction(actionEvent ->  {
            peaLava.setScene(stseen);
        });
        peaLava.setResizable(true);
        peaLava.setScene(stseen);
        peaLava.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public static void eemaldaFailist(String regNr) throws IOException{
        File temporaryFile = new File("dataUus.txt");
        File inputFile = new File("data.txt");

        BufferedWriter writer = new BufferedWriter(new FileWriter(temporaryFile));
        BufferedReader reader = new BufferedReader(new FileReader(inputFile));

        String lineToRemove = regNr;
        String currentLine;

        while((currentLine = reader.readLine()) != null) {

            // trim newline when comparing with lineToRemove
            String trimmedLine = currentLine.trim();
            if(trimmedLine.contains(lineToRemove)) continue;
            writer.write(currentLine + System.getProperty("line.separator"));
        }
        writer.close();
        reader.close();
        inputFile.delete();
        boolean successful = temporaryFile.renameTo(inputFile);

    }

    public void kirjutaFaili(String autoTüüp,String nimi, String regNr) {
        LocalDateTime algus = LocalDateTime.now();
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter("data.txt",true);
            fileWriter.write(autoTüüp+";"+nimi+";"+regNr+";"+algus);
            fileWriter.write("\n");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public int loeFailist(String regNr){
        LocalDateTime lõpp = LocalDateTime.now();
        String[] info = new String[0];
        // Open this file.
        BufferedReader reader = null;// Read lines from file.
        try {
            reader = new BufferedReader(new FileReader("data.txt"));
            while (true) {
                String line = reader.readLine();
                if (line == null) {
                    break;
                }
                String[] parts = line.split(";");
                String registreerimisNr = parts[2]; //kui reg nr võrdub etteantud numbriga, siis võtame info välja
                if(registreerimisNr.equals(regNr)){
                    info = parts;
                    break;
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(info.length != 0) {
            String autotüüp = info[0];
            String nimi1 = info[1];
            LocalDateTime algusAeg = LocalDateTime.parse(info[3]);
            int lõppSekundid = lõpp.getHour() * 3600 + lõpp.getMinute() * 60 + lõpp.getSecond();
            int algusSekundid = algusAeg.getHour() * 3600 + algusAeg.getMinute() * 60 + algusAeg.getSecond();
            int sekundeidKulus = lõppSekundid - algusSekundid;
            System.out.println(sekundeidKulus);
            return sekundeidKulus;
        }else{
            return 0;
        }

    }
}

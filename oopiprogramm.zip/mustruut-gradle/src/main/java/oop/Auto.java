package oop;

import java.util.Scanner;
public class Auto {
    private String regNr; //auto registreerimisnumber

}
